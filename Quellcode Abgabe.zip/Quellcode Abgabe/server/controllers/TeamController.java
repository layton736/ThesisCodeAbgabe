package controllers;

import play.mvc.Controller;

public class TeamController extends Controller{

}
