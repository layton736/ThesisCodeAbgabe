package game.exception;

public class BadNameException extends Exception {

	public BadNameException(String cause) {
		super(cause);
	}

}
